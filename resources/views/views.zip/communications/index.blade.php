@extends('layouts.layout')

@section('title','Notificaciones')

@section('content')

<!-- Start Content-->
<div class="container-fluid">
    
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <h4 class="page-title">Notificaciones</h4>
            </div>
        </div>
    </div>     


    
</div> <!-- container -->

@endsection