@extends('layouts.layout')

@section('title','Solicitudes')

@section('content')

<!-- Start Content-->
<div class="container-fluid">
    
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <h4 class="page-title">Solicitudes</h4>
            </div>
        </div>
    </div>     


    
</div> <!-- container -->

@endsection